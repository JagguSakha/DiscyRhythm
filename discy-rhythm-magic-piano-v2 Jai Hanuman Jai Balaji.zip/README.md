# Discy Rhythm — Magic Piano UI

A Fabric 26.1.2 rhythm-game screen for Minecraft.

## UI / gameplay update
- Reworked the UI using the Jaggu Client reference's dark rounded-card aesthetic.
- Added **Easy, Medium, Normal, Hard** modes.
- Difficulty changes note density and judgment timing.
- Replaced flat notes with glowing **magic-piano tiles**.
- Added lane glow, key pulses, spark bursts and hit feedback.
- Removed the health bar completely.
- Removed the old gameplay suggestion/get-ready overlay.
- Added cleaner score, combo, progress and results cards.
- Kept G/H/J/K rhythm controls.
- Menu: Up/Down selects tracks, Left/Right selects difficulty, Z/X adjusts timing offset, Enter starts.

## Build
Use the included Gradle wrapper in an environment with access to the Gradle distribution and Maven repositories:

```text
./gradlew build
```
