package com.discyrhythm.client;

import com.discyrhythm.DiscyRhythm;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public class DiscyRhythmClient implements ClientModInitializer {
	public static final KeyMapping.Category CATEGORY =
		KeyMapping.Category.register(Identifier.fromNamespaceAndPath(DiscyRhythm.MOD_ID, "main"));

	public static KeyMapping openKey;

	@Override
	public void onInitializeClient() {
		openKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
			"key.discyrhythm.open", InputConstants.Type.KEYSYM, InputConstants.KEY_RSHIFT, CATEGORY));

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (openKey.consumeClick()) {
				if (mc.screen == null) {
					mc.setScreen(new DiscyScreen());
				}
			}
		});
	}
}
