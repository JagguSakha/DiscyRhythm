package com.discyrhythm.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

/**
 * Discy Rhythm - polished piano-style rhythm screen.
 * Visual language is inspired by the Jaggu Client UI: dark cards, rounded panels,
 * animated gradients, compact spacing and soft accent glows.
 */
public class DiscyScreen extends Screen {
    private enum State { MENU, PLAYING, RESULTS }

    private enum Mode {
        EASY("Easy", 0.76f, 1.28f, 55, 105, 155, 0xFF66E6A8),
        MEDIUM("Medium", 0.92f, 1.10f, 50, 95, 145, 0xFF62C8FF),
        NORMAL("Normal", 1.06f, 1.00f, 45, 85, 135, 0xFFB58CFF),
        HARD("Hard", 1.26f, 0.90f, 38, 75, 120, 0xFFFF6D9B);

        final String name;
        final float density;
        final float speed;
        final long sick, good, bad;
        final int color;

        Mode(String name, float density, float speed, long sick, long good, long bad, int color) {
            this.name = name;
            this.density = density;
            this.speed = speed;
            this.sick = sick;
            this.good = good;
            this.bad = bad;
            this.color = color;
        }
    }

    private record Disc(String name, String sound, int bpm, int seconds, int color) {}

    private static final class Note {
        final long t;
        final int lane;
        boolean done;
        Note(long t, int lane) { this.t = t; this.lane = lane; }
    }

    private static final class Effect {
        float x, y, vx, vy, life, size;
        int color;
        Effect(float x, float y, float vx, float vy, float life, float size, int color) {
            this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.life=life; this.size=size; this.color=color;
        }
    }

    private static final Disc[] DISCS = {
        new Disc("Creator", "music_disc.creator", 100, 175, 0xFFE8A33D),
        new Disc("Creator (Music Box)", "music_disc.creator_music_box", 90, 73, 0xFFF2D27A),
        new Disc("Otherside", "music_disc.otherside", 100, 195, 0xFF4FB3BF),
        new Disc("Pigstep", "music_disc.pigstep", 112, 148, 0xFFD6486B),
        new Disc("5", "music_disc.5", 90, 178, 0xFF8A6FD1),
    };

    private static final int[] KEYS = {71, 72, 74, 75}; // G H J K
    private static final String[] LABELS = {"G", "H", "J", "K"};
    private static final int[] LANE_COLORS = {0xFFC85CFF, 0xFF47D9FF, 0xFF55E6A8, 0xFFFF6C9C};
    
    private static final int LANE_W = 50;
    private static final int GAP = 7;
    private static final int TILE_H = 17;
    private static final long APPROACH_MS = 1450;
    private static final long LEAD_MS = 2200;
    private static final long MAX_OFFSET = 1000;

    private static long offsetMs = 0;
    private State state = State.MENU;
    private int sel = 0;
    private int modeIndex = 2;
    private List<Note> notes = new ArrayList<>();
    private final List<Effect> effects = new ArrayList<>();
    private long songStartNs;
    private boolean musicStarted;
    private SoundInstance current;
    private int score, combo, maxCombo, sick, good, bad, miss, total;
    private String judge = "";
    private int judgeColor = 0xFFFFFFFF;
    private long judgeAt;
    private long lastFrameNs = System.nanoTime();
    private final long[] pressedAt = new long[4];
    private final float[] lanePulse = new float[4];

    public DiscyScreen() { super(Component.literal("Discy Rhythm")); }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void removed() { stopMusic(); super.removed(); }

    private Mode mode() { return Mode.values()[modeIndex]; }
    private long clock() { return (System.nanoTime() - songStartNs) / 1_000_000L + offsetMs; }

    private void stopMusic() {
        if (current != null) {
            Minecraft.getInstance().getSoundManager().stop(current);
            current = null;
        }
    }

    private List<Note> buildChart(Disc d) {
        Random r = new Random((long)d.name().hashCode() * 31L + modeIndex * 997L);
        double step = 60000.0 / d.bpm() / 2.0;
        long end = d.seconds() * 1000L - 4000;
        List<Note> list = new ArrayList<>();
        int last = -1;
        for (int i = 8; i * step < end; i++) {
            double sec = i * step / 1000.0;
            double wave = 0.34 + 0.18 * Math.sin(sec / 8.5) + Math.min(0.18, sec / 500.0);
            boolean beat = i % 2 == 0;
            double chance = Math.max(0.12, Math.min(0.94, wave * mode().density));
            if (!beat && r.nextDouble() > chance * 0.82) continue;
            if (beat && r.nextDouble() > Math.min(0.96, chance + 0.28)) continue;
            int lane = r.nextInt(4);
            if (lane == last && r.nextBoolean()) lane = (lane + 1 + r.nextInt(3)) % 4;
            list.add(new Note((long)(i * step), lane));
            last = lane;
            if (mode() != Mode.EASY && beat && r.nextDouble() < 0.055 * mode().density) {
                list.add(new Note((long)(i * step), (lane + 1 + r.nextInt(3)) % 4));
            }
        }
        return list;
    }

    private void startSong() {
        notes = buildChart(DISCS[sel]);
        effects.clear();
        score = combo = maxCombo = sick = good = bad = miss = total = 0;
        judge = "";
        musicStarted = false;
        songStartNs = System.nanoTime() + LEAD_MS * 1_000_000L;
        Arrays.fill(pressedAt, 0);
        Arrays.fill(lanePulse, 0f);
        state = State.PLAYING;
    }

    private void playMusic() {
        SoundEvent ev = SoundEvent.createVariableRangeEvent(Identifier.withDefaultNamespace(DISCS[sel].sound()));
        current = SimpleSoundInstance.forUI(ev, 1.0f, 1.0f);
        Minecraft.getInstance().getSoundManager().play(current);
        musicStarted = true;
    }

    private void setJudge(String s, int color) {
        judge = s; judgeColor = color; judgeAt = System.currentTimeMillis();
    }

    private void spawnBurst(int lane, int y, int count) {
        float cx = laneCenter(lane);
        Random r = new Random(System.nanoTime() ^ ((long)lane << 17));
        for (int i = 0; i < count; i++) {
            double a = r.nextDouble() * Math.PI * 2.0;
            float speed = 25f + r.nextFloat() * 65f;
            effects.add(new Effect(cx, y, (float)Math.cos(a)*speed, (float)Math.sin(a)*speed,
                0.45f + r.nextFloat()*0.35f, 1.5f + r.nextFloat()*2.2f, LANE_COLORS[lane]));
        }
    }

    private void onMiss() {
        miss++; total++; combo = 0;
        setJudge("MISS", 0xFFFF607F);
    }

    private void update() {
        long nowNs = System.nanoTime();
        float dt = Math.min(0.05f, (nowNs - lastFrameNs) / 1e9f);
        lastFrameNs = nowNs;
        for (int i=0;i<4;i++) lanePulse[i] = Math.max(0f, lanePulse[i] - dt * 3.6f);
        for (int i=effects.size()-1;i>=0;i--) {
            Effect e=effects.get(i); e.life -= dt; e.x += e.vx*dt; e.y += e.vy*dt; e.vy += 70f*dt;
            if (e.life <= 0) effects.remove(i);
        }
        if (state != State.PLAYING) return;
        long c = clock();
        if (!musicStarted && c >= offsetMs) playMusic();
        for (Note n : notes) {
            if (!n.done && c - n.t > mode().bad) { n.done = true; onMiss(); }
        }
        if (c > DISCS[sel].seconds()*1000L - 2500) finish();
    }

    private void finish() { stopMusic(); state = State.RESULTS; }

    private void hit(int lane) {
        pressedAt[lane] = System.currentTimeMillis();
        lanePulse[lane] = 1f;
        long c = clock();
        Note best = null;
        for (Note n : notes) {
            if (n.done || n.lane != lane) continue;
            if (n.t - c > mode().bad) break;
            if (Math.abs(n.t-c) <= mode().bad && (best==null || Math.abs(n.t-c)<Math.abs(best.t-c))) best=n;
        }
        if (best == null) { spawnBurst(lane, receptorY(), 5); return; }
        best.done = true;
        long d = Math.abs(best.t-c);
        total++; combo++; maxCombo=Math.max(maxCombo,combo);
        if (d <= mode().sick) { sick++; score += 350; setJudge("PERFECT", 0xFF7EF7FF); spawnBurst(lane,receptorY(),18); }
        else if (d <= mode().good) { good++; score += 200; setJudge("GREAT", 0xFF77F2B0); spawnBurst(lane,receptorY(),13); }
        else { bad++; score += 100; setJudge("GOOD", 0xFFFFCF70); spawnBurst(lane,receptorY(),8); }
    }

    private double accuracy() {
        if (total==0) return 100.0;
        return (sick + good*0.75 + bad*0.4) / total * 100.0;
    }

    private String rank() {
        double a=accuracy();
        if (a>=95) return "S"; if (a>=85) return "A"; if (a>=70) return "B"; if (a>=55) return "C"; return "D";
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key=event.key();
        if (key==344) { onClose(); return true; }
        switch(state) {
            case MENU -> {
                if (key==265) sel=(sel+DISCS.length-1)%DISCS.length;
                else if (key==264) sel=(sel+1)%DISCS.length;
                else if (key==263) modeIndex=(modeIndex+Mode.values().length-1)%Mode.values().length;
                else if (key==262) modeIndex=(modeIndex+1)%Mode.values().length;
                else if (key==90) offsetMs=Math.max(-MAX_OFFSET,offsetMs-10); // Z
                else if (key==88) offsetMs=Math.min(MAX_OFFSET,offsetMs+10); // X
                else if (key==257 || key==335) startSong();
                else if (key==256) onClose();
                return true;
            }
            case PLAYING -> {
                if (key==256) { stopMusic(); state=State.MENU; return true; }
                for(int i=0;i<4;i++) if(key==KEYS[i]) { hit(i); return true; }
                return true;
            }
            case RESULTS -> {
                if(key==82) startSong();
                else if(key==257 || key==335 || key==256) state=State.MENU;
                return true;
            }
        }
        return super.keyPressed(event);
    }

    // ------------------------- drawing -------------------------
    private int accent(float t) {
        float time=(System.currentTimeMillis()%9000L)/9000f;
        float p=(t+time*0.7f)%1f;
        return lerp(mode().color, DISCS[sel].color(), p);
    }
    private int lerp(int a,int b,float t) {
        t=Math.max(0,Math.min(1,t));
        return 0xFF000000 | ((int)(((a>>16)&255)+(((b>>16)&255)-((a>>16)&255))*t)<<16)
            | ((int)(((a>>8)&255)+(((b>>8)&255)-((a>>8)&255))*t)<<8)
            | (int)((a&255)+((b&255)-(a&255))*t);
    }
    private int alpha(int c,int a){ return ((Math.max(0,Math.min(255,a)))<<24)|(c&0xFFFFFF); }
    private void rect(GuiGraphicsExtractor g,int x,int y,int w,int h,int c){g.fill(x,y,x+w,y+h,c);}
    private void round(GuiGraphicsExtractor g,int x,int y,int w,int h,int r,int c){
        r=Math.max(0,Math.min(r,Math.min(w,h)/2));
        if(r==0){rect(g,x,y,w,h,c);return;}
        rect(g,x,y+r,w,h-2*r,c); rect(g,x+r,y,w-2*r,r,c); rect(g,x+r,y+h-r,w-2*r,r,c);
        for(int i=0;i<r;i++){
            double dy=r-i-.5, dx=Math.sqrt(r*r-dy*dy); int inset=Math.max(1,(int)Math.round(r-dx));
            rect(g,x+inset,y+i,w-2*inset,1,c); rect(g,x+inset,y+h-i-1,w-2*inset,1,c);
        }
    }
    private void panel(GuiGraphicsExtractor g,int x,int y,int w,int h,int r,int border,int fill){round(g,x,y,w,h,r,border);round(g,x+1,y+1,w-2,h-2,Math.max(0,r-1),fill);}
    private void shadow(GuiGraphicsExtractor g,int x,int y,int w,int h,int r){for(int i=7;i>=1;i--)round(g,x-i,y+i/2,w+i*2,h+i*2,r+i,(7-i)*4<<24);}
    private void text(GuiGraphicsExtractor g,String s,int x,int y,int c){g.text(this.font,s,x,y,c,false);}
    private void center(GuiGraphicsExtractor g,String s,int y,int c){text(g,s,(width-this.font.width(s))/2,y,c);}
    private void centerAt(GuiGraphicsExtractor g,String s,int cx,int y,int c){text(g,s,cx-this.font.width(s)/2,y,c);}
    private int width(String s){return this.font.width(s);}
    private int laneFieldW(){return 4*LANE_W+3*GAP;}
    private int laneLeft(){return (width-laneFieldW())/2;}
    private int receptorY(){return height-86;}
    private float laneCenter(int lane){return laneLeft()+lane*(LANE_W+GAP)+LANE_W/2f;}

    @Override
    public void extractRenderState(GuiGraphicsExtractor g,int mouseX,int mouseY,float delta) {
        update();
        g.fill(0,0,width,height,0xFF090A10);
        // subtle background grid / aura
        for(int x=0;x<width;x+=48) rect(g,x,0,1,height,0x081FFFFF);
        for(int y=0;y<height;y+=48) rect(g,0,y,width,1,0x061FFFFFF);
        rect(g,0,0,width,3,accent(0));
        switch(state){case MENU->drawMenu(g);case PLAYING->drawGame(g);case RESULTS->drawResults(g);}
    }

    private void header(GuiGraphicsExtractor g,String eyebrow,String title,String sub) {
        text(g,eyebrow.toUpperCase(),28,18,alpha(accent(.1f),220));
        text(g,title,28,35,0xFFF5F5FA);
        text(g,sub,28,53,0xFF777A8B);
        round(g,28,66,width-56,1,0,0xFF252733);
    }

    private void drawMenu(GuiGraphicsExtractor g) {
        header(g,"DISCY RHYTHM","Magic Piano","Choose a track and a difficulty");
        int sidebarW=Math.min(190,width/3);
        int sx=28, sy=84, sh=height-112;
        shadow(g,sx,sy,sidebarW,sh,9); panel(g,sx,sy,sidebarW,sh,9,0xFF282A36,0xF511121A);
        text(g,"DIFFICULTY",sx+16,sy+17,0xFF737689);
        Mode[] ms=Mode.values();
        for(int i=0;i<ms.length;i++){
            int y=sy+34+i*45; boolean on=i==modeIndex;
            if(on){ round(g,sx+10,y,sidebarW-20,36,7,alpha(ms[i].color,48)); round(g,sx+10,y,3,36,1,ms[i].color); }
            text(g,ms[i].name,sx+22,y+8,on?0xFFFFFFFF:0xFF9A9CAB);
            text(g, i==0?"Relaxed":i==1?"Balanced":i==2?"Fast & precise":"Maximum speed",sx+22,y+22,on?0xFF8C8F9F:0xFF606270);
            round(g,sx+sidebarW-31,y+11,8,8,4,ms[i].color);
        }
        text(g,"OFFSET",sx+16,sy+235,0xFF737689);
        text(g,String.format("%+d ms",offsetMs),sx+16,sy+254,0xFFE8E8F0);
        text(g,"Z / X",sx+sidebarW-50,sy+254,0xFF666978);
        text(g,"G  H  J  K",sx+16,sy+sh-22,0xFF686A79);

        int cx=sx+sidebarW+18, cw=width-cx-28;
        text(g,"TRACKS",cx,sy+17,0xFF737689);
        int y=sy+34;
        for(int i=0;i<DISCS.length;i++){
            Disc d=DISCS[i]; boolean on=i==sel; int h=54;
            shadow(g,cx,y,cw,h,8); panel(g,cx,y,cw,h,8,on?alpha(d.color,170):0xFF272935,on?0xF71A1B24:0xF312131A);
            round(g,cx+12,y+13,28,28,8,alpha(d.color,on?210:95));
            centerAt(g,"♪",cx+26,y+19,0xFFFFFFFF);
            text(g,d.name,cx+52,y+9,on?0xFFF4F4F8:0xFFB0B1BD);
            text(g,d.bpm+" BPM  •  "+(d.seconds/60)+":"+String.format("%02d",d.seconds%60),cx+52,y+27,0xFF6F7180);
            if(on){ round(g,cx+cw-44,y+19,24,16,8,alpha(d.color,80)); centerAt(g,"PLAY",cx+cw-32,y+22,0xFFFFFFFF); }
            y+=62;
        }
        int fy=height-43;
        text(g,"↑ / ↓",cx,fy,0xFF696B7A); text(g,"TRACK",cx+43,fy,0xFF3E404B);
        text(g,"ENTER",cx+cw-116,fy,0xFF8C8E9B); text(g,"PLAY",cx+cw-70,fy,0xFF5A5C68);
    }

    private void drawGame(GuiGraphicsExtractor g) {
        Disc d=DISCS[sel]; long c=clock(); int px=laneLeft(); int rec=receptorY();
        // top HUD cards
        round(g,20,14,150,42,8,0xE914151D); text(g,d.name,32,23,0xFFEDEDF4); text(g,mode().name+" MODE",32,38,mode().color);
        round(g,width-176,14,156,42,8,0xE914151D); text(g,"SCORE",width-162,22,0xFF707282); text(g,String.valueOf(score),width-162,36,0xFFF3F3F7);
        center(g,combo>1?combo+"x COMBO":"READY",24,combo>1?mode().color:0xFF6C6E7C);
        // lane deck
        int top=76, bottom=rec+20;
        for(int i=0;i<4;i++){
            int x=px+i*(LANE_W+GAP);
            round(g,x,top,LANE_W,bottom-top,9,0xFF10121A);
            round(g,x+1,top+1,LANE_W-2,bottom-top-2,8,alpha(LANE_COLORS[i],12+(int)(lanePulse[i]*28)));
            if(lanePulse[i]>0) round(g,x-3,rec-4,LANE_W+6,28,10,alpha(LANE_COLORS[i],(int)(lanePulse[i]*55)));
        }
        // progress strip
        float prog=Math.max(0,Math.min(1,c/(float)(d.seconds()*1000L)));
        round(g,px,68,laneFieldW(),3,1,0xFF242632); round(g,px,68,(int)(laneFieldW()*prog),3,1,accent(.25f));

        // magic piano tiles
        for(Note n:notes){
            if(n.done) continue;
            double frac=(n.t-c)/(double)(APPROACH_MS/mode().speed);
            if(frac>1.08) break;
            int y=rec-(int)(frac*(rec-top));
            if(y<top-30||y>rec+30) continue;
            int x=px+n.lane*(LANE_W+GAP);
            int glow=alpha(LANE_COLORS[n.lane],Math.max(0,Math.min(95,(int)(90*(1-frac)))));
            round(g,x-5,y-5,LANE_W+10,TILE_H+10,9,glow);
            round(g,x,y,LANE_W,TILE_H,6,LANE_COLORS[n.lane]);
            round(g,x+5,y+4,LANE_W-10,3,2,0x77FFFFFF);
            round(g,x+10,y+8,LANE_W-20,3,2,0x33FFFFFF);
        }
        // piano keys
        for(int i=0;i<4;i++){
            int x=px+i*(LANE_W+GAP); boolean down=System.currentTimeMillis()-pressedAt[i]<110;
            round(g,x,rec,LANE_W,20,6,down?LANE_COLORS[i]:0xFF1C1E28);
            round(g,x+1,rec+1,LANE_W-2,18,5,down?alpha(LANE_COLORS[i],180):0xFF11131A);
            centerAt(g,LABELS[i],x+LANE_W/2,rec+5,down?0xFFFFFFFF:0xFF858795);
        }
        // judge and combo, deliberately clean: no health bar and no suggestion overlay
        long ago=System.currentTimeMillis()-judgeAt;
        if(ago<600&&!judge.isEmpty()){
            float a=1f-ago/600f;
            center(g,judge,rec-34,alpha(judgeColor,(int)(255*a)));
            if(combo>1) center(g,combo+"x",rec-20,alpha(0xFFFFFFFF,(int)(220*a)));
        }
        for(Effect e:effects){
            int a=(int)Math.max(0,Math.min(255,e.life*320));
            round(g,(int)e.x-2,(int)e.y-2,(int)e.size+4,(int)e.size+4,4,alpha(e.color,a));
        }
        if(c<0) center(g,"♪",height/2-8,0xAAFFFFFF);
    }

    private void drawResults(GuiGraphicsExtractor g) {
        int pw=Math.min(460,width-40), ph=300, x=(width-pw)/2, y=(height-ph)/2;
        shadow(g,x,y,pw,ph,12); panel(g,x,y,pw,ph,12,0xFF2B2D3A,0xF611121A);
        center(g,"SONG COMPLETE",y+28,0xFF777A8A);
        center(g,DISCS[sel].name,y+50,0xFFF4F4F8);
        center(g,mode().name+" MODE",y+68,mode().color);
        round(g,width/2-40,y+88,80,52,12,alpha(mode().color,40));
        centerAt(g,rank(),width/2,y+101,mode().color);
        center(g,"RANK",y+119,0xFF777A8A);
        text(g,"SCORE",x+34,y+155,0xFF6F7180); text(g,String.valueOf(score),x+34,y+170,0xFFF0F0F5);
        text(g,"ACCURACY",x+180,y+155,0xFF6F7180); text(g,String.format("%.1f%%",accuracy()),x+180,y+170,0xFFF0F0F5);
        text(g,"MAX COMBO",x+326,y+155,0xFF6F7180); text(g,String.valueOf(maxCombo),x+326,y+170,0xFFF0F0F5);
        round(g,x+34,y+196,pw-68,1,0,0xFF292B36);
        center(g,"PERFECT  "+sick+"     GREAT  "+good+"     GOOD  "+bad+"     MISS  "+miss,y+213,0xFF9294A2);
        center(g,"R  RETRY",y+246,0xFFB0B2C0); center(g,"ENTER  MENU",y+263,0xFF666876);
    }
}
