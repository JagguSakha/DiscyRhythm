package com.discyrhythm;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DiscyRhythm implements ModInitializer {
	public static final String MOD_ID = "discyrhythm";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("Discy Rhythm loaded - Jai Jaggannath! Jai Ganesh!");
	}
}
